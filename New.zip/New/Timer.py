dt: float = 0
entities = []